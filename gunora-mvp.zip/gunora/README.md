# GÜNORA MVP

GÜNORA'nın ilk mobil ekran prototipi: "Bugün ne var?"

## Çalıştırma

```bash
npm install
npx expo start
```

Bu ilk sürüm gerçek API'lara bağlı değildir; ekran veri akışlarını temsil eden örnek içerik kullanır.

## Sonraki modüller
- Weather API
- Finance/pricing APIs
- News aggregation + AI summary
- Sports API
- Location/event discovery
- Push notifications
- User interests + personalization
