import React from 'react';
import { SafeAreaView, ScrollView, StyleSheet, Text, View, Pressable } from 'react-native';
import { StatusBar } from 'expo-status-bar';

const navy = '#14235C';
const orange = '#F8A900';
const text = '#1D2433';
const muted = '#7C8496';
const green = '#13A65B';

function Card({ children, style }: { children: React.ReactNode; style?: any }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export default function App() {
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.page} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.logo}><Text style={{color: navy}}>GÜN</Text><Text style={{color: orange}}>O</Text><Text style={{color: navy}}>RA</Text></Text>
            <Text style={styles.tagline}>Bugün ne var?</Text>
          </View>
          <View style={styles.location}><Text style={styles.locationDot}>●</Text><Text style={styles.locationText}>İstanbul</Text></View>
        </View>

        <View style={styles.greetingRow}>
          <View>
            <Text style={styles.greeting}>Günaydın! ☀️</Text>
            <Text style={styles.date}>18 Ağustos 2026, Salı</Text>
          </View>
          <Pressable style={styles.summaryPill}><Text style={styles.summaryText}>✓ Bugün için 7 önemli özet</Text><Text style={styles.chevron}>›</Text></Pressable>
        </View>

        <Card style={styles.weatherCard}>
          <View style={styles.weatherTop}>
            <View style={{flexDirection:'row', alignItems:'center'}}>
              <Text style={styles.sun}>☀</Text>
              <View>
                <Text style={styles.temp}>28°</Text>
                <Text style={styles.weatherText}>Açık</Text>
              </View>
            </View>
            <View style={styles.hourly}>
              {[['10:00','29°'],['13:00','31°'],['16:00','30°'],['19:00','27°']].map(([t,v]) => <View key={t} style={styles.hour}><Text style={styles.hourTime}>{t}</Text><Text style={styles.hourSun}>☀</Text><Text style={styles.hourTemp}>{v}</Text></View>)}
            </View>
          </View>
          <Text style={styles.weatherMeta}>Hissedilen 30°  ·  Nem %47</Text>
          <Text style={styles.weatherNote}>Bugün yağmur beklenmiyor.</Text>
          <Pressable style={styles.weatherButton}><Text style={styles.weatherButtonText}>Detaylı Hava Durumu  ›</Text></Pressable>
        </Card>

        <View style={styles.threeCols}>
          <Card style={styles.smallCard}><Text style={styles.cardTitle}>⛽  AKARYAKIT</Text><Row label="Benzin" value="56,20 TL"/><Row label="Motorin" value="55,10 TL"/><Row label="LPG" value="27,59 TL"/><MiniButton text="En Ucuz İstasyonlar  ›" /></Card>
          <Card style={styles.smallCard}><Text style={[styles.cardTitle,{color:'#D29100'}]}>💰  PARA PİYASALARI</Text><Row label="Gram Altın" value="7.420 TL  ↑"/><Row label="Dolar" value="41,20 TL  ↑"/><Row label="Euro" value="47,90 TL  ↓"/><MiniButton text="Tüm Piyasalar  ›" /></Card>
          <Card style={styles.smallCard}><Text style={[styles.cardTitle,{color:'#7940BE'}]}>🚗  TRAFİK</Text><View style={styles.traffic}><Text style={styles.trafficPct}>%42</Text><View><Text style={styles.trafficText}>Orta Yoğunluk</Text><Text style={styles.city}>İstanbul</Text></View></View><MiniButton text="Trafiğe Bak  ›" /></Card>
        </View>

        <Card><View style={styles.sectionHeader}><Text style={styles.sectionTitle}>📰  BUGÜNÜN 5 ÖNEMLİ GELİŞMESİ</Text><Text style={styles.link}>Tümünü Gör  ›</Text></View>{[
          'Merkez Bankası politika faizini %50’de sabit tuttu.',
          'TÜİK: Temmuz ayında enflasyon aylık %2,06 arttı.',
          "İstanbul'da toplu taşımaya zam kararı alındı.",
          'Avrupa borsaları günü yükselişle tamamladı.',
          'Milli takımımız hazırlık maçında galip geldi.'
        ].map((n,i)=><View style={styles.newsRow} key={n}><Text style={styles.newsNo}>{i+1}</Text><Text style={styles.newsText}>{n}</Text></View>)}</Card>

        <View style={styles.twoCols}>
          <Card><View style={styles.sectionHeader}><Text style={styles.sectionTitle}>⚽  BUGÜNKÜ MAÇLAR</Text><Text style={styles.link}>Tümünü Gör</Text></View><Match time="20:00" league="Süper Lig" left="GS" right="FB"/><Match time="22:00" league="La Liga" left="RMA" right="BAR"/><MiniButton text="Tüm Maçlar  ›" /></Card>
          <Card><View style={styles.sectionHeader}><Text style={[styles.sectionTitle,{color:'#D86D12'}]}>📍  YAKININDA NE VAR?</Text><Text style={styles.link}>Tümünü Gör</Text></View><Near title="Yaz Konserleri" place="Harbiye Açıkhava" dist="1,2 km"/><Near title="İndirim Günleri" place="Zorlu Center" dist="2,1 km"/><Near title="Sergi: Zamanın İzleri" place="İstanbul Modern" dist="2,8 km"/><MiniButton text="Tüm Etkinlikler  ›" /></Card>
        </View>

        <Card style={styles.foodCard}><View style={styles.foodImage}><Text style={{fontSize:48}}>🍝</Text></View><View style={{flex:1,paddingHorizontal:14}}><Text style={[styles.sectionTitle,{color:green}]}>🍴  BUGÜN NE YİYELİM?</Text><Text style={styles.foodSub}>20 dakikada hazırlanır, 4 kişilik</Text><Text style={styles.foodName}>Domatesli Makarna</Text><Text style={styles.foodCost}>Tahmini maliyet: <Text style={{color:green,fontWeight:'700'}}>150 TL</Text></Text></View><Pressable style={styles.recipe}><Text style={styles.recipeText}>Tarife Git  ›</Text></Pressable></Card>

        <View style={styles.nav}><NavItem icon="⌂" text="Bugün" active/><NavItem icon="▤" text="Haberler"/><NavItem icon="⌁" text="Finans"/><NavItem icon="⚽" text="Spor"/><NavItem icon="◯" text="Profil"/></View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Row({label,value}:{label:string;value:string}){ return <View style={styles.row}><Text style={styles.rowLabel}>{label}</Text><Text style={styles.rowValue}>{value}</Text></View>; }
function MiniButton({text:label}:{text:string}){ return <Pressable style={styles.miniButton}><Text style={styles.miniButtonText}>{label}</Text></Pressable>; }
function Match({time,league,left,right}:{time:string;league:string;left:string;right:string}){return <View style={styles.match}><Text style={styles.team}>{left}</Text><View><Text style={styles.matchTime}>{time}</Text><Text style={styles.league}>{league}</Text></View><Text style={styles.team}>{right}</Text></View>}
function Near({title,place,dist}:{title:string;place:string;dist:string}){return <View style={styles.near}><Text style={styles.nearIcon}>•</Text><View style={{flex:1}}><Text style={styles.nearTitle}>{title}</Text><Text style={styles.nearPlace}>{place}</Text></View><Text style={styles.nearDist}>{dist}</Text></View>}
function NavItem({icon,text:label,active}:{icon:string;text:string;active?:boolean}){return <View style={styles.navItem}><Text style={[styles.navIcon,active&&{color:navy}]}>{icon}</Text><Text style={[styles.navText,active&&{color:navy,fontWeight:'700'}]}>{label}</Text></View>}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:'#F7F8FC'}, page:{padding:18,paddingBottom:28}, header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:18}, logo:{fontSize:34,fontWeight:'900',letterSpacing:1}, tagline:{fontSize:13,color:muted,marginTop:1}, location:{paddingHorizontal:14,paddingVertical:10,borderRadius:22,backgroundColor:'#fff',flexDirection:'row',alignItems:'center',shadowOpacity:.06,shadowRadius:8,elevation:2},locationDot:{color:'#1D72F5',fontSize:15},locationText:{color:text,fontWeight:'700',marginLeft:6}, greetingRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:16},greeting:{fontSize:24,fontWeight:'800',color:text},date:{color:muted,marginTop:4},summaryPill:{backgroundColor:'#fff',borderRadius:22,paddingVertical:11,paddingHorizontal:14,flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:'#EDF0F5'},summaryText:{fontWeight:'700',fontSize:12,color:'#475067'},chevron:{fontSize:20,marginLeft:5,color:navy},card:{backgroundColor:'#fff',borderRadius:20,padding:15,marginBottom:12,shadowOpacity:.045,shadowRadius:8,elevation:1},weatherCard:{backgroundColor:'#4288F5',padding:18},weatherTop:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},sun:{fontSize:55,color:orange,marginRight:14},temp:{fontSize:44,fontWeight:'900',color:'#fff',lineHeight:44},weatherText:{fontSize:17,color:'#fff',fontWeight:'700'},hourly:{flexDirection:'row',borderLeftWidth:1,borderLeftColor:'rgba(255,255,255,.35)',paddingLeft:14},hour:{alignItems:'center',marginLeft:11},hourTime:{fontSize:11,color:'#E8F0FF'},hourSun:{fontSize:18,marginVertical:4},hourTemp:{fontSize:15,fontWeight:'700',color:'#fff'},weatherMeta:{color:'#E8F0FF',marginTop:12},weatherNote:{color:'#fff',fontWeight:'800',marginTop:5},weatherButton:{alignSelf:'flex-end',marginTop:12,backgroundColor:'rgba(255,255,255,.16)',borderRadius:18,paddingVertical:9,paddingHorizontal:14},weatherButtonText:{color:'#fff',fontWeight:'700',fontSize:12},threeCols:{flexDirection:'row',gap:10},smallCard:{flex:1,padding:12},cardTitle:{fontSize:11,fontWeight:'800',color:'#16834E',marginBottom:9},row:{flexDirection:'row',justifyContent:'space-between',marginVertical:5},rowLabel:{fontSize:11,color:'#656D7D'},rowValue:{fontSize:11,fontWeight:'800',color:text},miniButton:{marginTop:10,borderRadius:14,paddingVertical:9,paddingHorizontal:8,backgroundColor:'#EFF8F2',alignItems:'center'},miniButtonText:{fontSize:11,color:green,fontWeight:'800'},traffic:{flexDirection:'row',alignItems:'center',gap:8,marginVertical:11},trafficPct:{fontSize:23,fontWeight:'900',color:'#7B56C7'},trafficText:{fontSize:11,fontWeight:'800',color:text},city:{fontSize:10,color:muted,marginTop:2},sectionHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:10},sectionTitle:{fontSize:12,fontWeight:'900',color:'#155EC7'},link:{fontSize:10,color:'#1E72E5',fontWeight:'700'},newsRow:{flexDirection:'row',alignItems:'center',marginVertical:5},newsNo:{width:24,height:24,borderRadius:12,backgroundColor:'#E9F1FF',textAlign:'center',paddingTop:4,color:'#3377E8',fontWeight:'900',fontSize:11},newsText:{flex:1,marginLeft:8,fontSize:12,color:'#394153',lineHeight:17},twoCols:{flexDirection:'row',gap:10},match:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingVertical:9},team:{fontWeight:'900',fontSize:12,color:text},matchTime:{textAlign:'center',fontWeight:'900',fontSize:15,color:text},league:{textAlign:'center',fontSize:9,color:muted,marginTop:2},near:{flexDirection:'row',alignItems:'center',marginVertical:7},nearIcon:{width:22,height:22,borderRadius:11,backgroundColor:'#FFF2E5',textAlign:'center',paddingTop:1,color:'#E77A23',fontWeight:'900'},nearTitle:{fontSize:11,fontWeight:'800',color:text},nearPlace:{fontSize:10,color:muted,marginTop:2},nearDist:{fontSize:10,color:muted},foodCard:{flexDirection:'row',alignItems:'center',padding:10},foodImage:{width:95,height:95,borderRadius:16,backgroundColor:'#F6F0E8',alignItems:'center',justifyContent:'center'},foodSub:{fontSize:10,color:muted,marginTop:4},foodName:{fontSize:16,fontWeight:'900',color:text,marginTop:7},foodCost:{fontSize:10,color:muted,marginTop:6},recipe:{backgroundColor:'#13A65B',borderRadius:17,paddingHorizontal:14,paddingVertical:11},recipeText:{color:'#fff',fontWeight:'800',fontSize:11},nav:{backgroundColor:'#fff',borderRadius:20,paddingVertical:9,flexDirection:'row',justifyContent:'space-around',marginTop:3},navItem:{alignItems:'center',minWidth:54},navIcon:{fontSize:20,color:'#8A91A2'},navText:{fontSize:10,color:'#8A91A2',marginTop:3}
});
